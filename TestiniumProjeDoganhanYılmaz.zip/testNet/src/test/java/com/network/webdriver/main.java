package com.network.webdriver;


import com.network.webdriver.methods ;

import org.apache.logging.log4j.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.selector.BasicContextSelector;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import io.github.bonigarcia.wdm.WebDriverManager;

public class main {
	
	
	
	public static void main(String[] args) throws InterruptedException 
	{
		
		
		Logger demlog = LogManager.getLogger(main.class);
		
		
		
		String basePage = "https://www.network.com.tr/";
		String searchword ="ceket";
		String secondPage ="https://www.network.com.tr/search?searchKey=ceket&page=2";
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		ChromeOptions options  = new ChromeOptions();
		Actions action = new Actions(driver);
		
		
		driver.get(basePage);
		driver.manage().deleteAllCookies(); 
		driver.manage().window().maximize();
		WebElement e = driver. findElement(By.cssSelector("#onetrust-accept-btn-handler"));;
		e.sendKeys(Keys.ENTER);
		
		
		demlog.info("Page Opened");
		
		
		String aa = driver.getCurrentUrl();
		
		
        com.network.webdriver.methods.checkURL(aa, basePage);
        demlog.info("URLs Checked");
        WebElement search = driver.findElement(By.name("searchKey"));
        search.sendKeys(searchword);
        search.sendKeys(Keys.ENTER);
        
        demlog.info("Keyword 'ceket' Entered");
        //Thread.sleep(3000);
        
        JavascriptExecutor js = (JavascriptExecutor) driver;
        
        js.executeScript("window.scrollBy(0,15500)", "");
        
       
        
        
	
        driver.findElement(By.cssSelector(".button.-secondary.-sm.relative")).click();
        Thread.sleep(2000);
        aa = driver.getCurrentUrl();

        com.network.webdriver.methods.checkURL(aa, secondPage);
        
        //BURASI DEG��ECEK
        /*
        WebElement a =driver(By.linkText("%"));
        
        
        a.sendKeys(Keys.ENTER);;
        */
        /*
        Integer row = 0;
        Integer col = 0;
        WebElement xx = driver(By.xpath("//class[@id='products__item']//tr[" + row.toString() + "]//td[" + col.toString() + "]"));
        */
      
        
	}
}