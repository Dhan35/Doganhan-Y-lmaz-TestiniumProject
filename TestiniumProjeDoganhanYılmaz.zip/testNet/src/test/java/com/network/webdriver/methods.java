package com.network.webdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import io.github.bonigarcia.wdm.WebDriverManager;

public class methods
{
	
	WebDriver driver = new ChromeDriver();
	
	public static void checkURL(String a , String b) {
        
        Assert.assertEquals(a, b);
	}
	public void waitSecond(long seconds) {
        try {
            Thread.sleep(seconds * 1000);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
	public void loginCSV()
	{
		
	}



}
